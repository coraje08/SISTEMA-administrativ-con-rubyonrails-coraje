require 'test_helper'

class WarehouseRecordTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
